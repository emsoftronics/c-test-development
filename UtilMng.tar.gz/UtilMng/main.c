#include "UtilMngDb.h"
#include <string.h>
#define DEMO_DB (UI_8 *)"/home/lnt/demo.db"

t_util_db my_db = UM_DB_INIT;

typedef struct 
{
    int a;
    char b;
    char name[20];
    unsigned long int l;
} t_test;

t_test td = {1880,'#',"jagdish Prajapti", 7898491071};


BOOL flag = FALSE;

/**
 * @brief This is callback which will be called automatically each time for 
 * every row return by query execution.
 * @param ex_buf external buffer
 * @param argc no of colums return
 * @param argv values corresponding column
 * @param colname name of corresponding column
 *
 */

static int db_callback(void * ex_buf, int argc, char **argv, char **colname)
{
    int i;
    if (flag)
    {
        printf("---------------------------------------------------------------------------------------\n");
        for(i=0; i<argc; i++){
            printf(" %12s |", colname[i]);
        }
        printf("\n---------------------------------------------------------------------------------------\n");
        flag = FALSE;
    }
    for(i=0; i<argc; i++){
        printf(" %12s |",  argv[i] ? argv[i] : "NULL");
    }
    printf("\n");
    return 0;
}

int main(int argc, char **argv )
{
    int id = 2;
 //   char dt[] = "2016-09-24 00:20:55"; 
    t_Util_recrd_col_val rcv ={"id", &id, UM_DB_INTEGER, "data", &td, UM_DB_BINARY,sizeof(td)};
     if (UtilMngInitDb(&my_db, DEMO_DB, db_callback) != 0)
         printf("Database initialization failed!!\n");
     if (argc == 2)
     {
         
        flag =TRUE;
        if (UtilMngExecQuery(&my_db, argv[1], NULL) != 0)
            printf("Database query failed!!\n");
        flag =FALSE;
     }
     else if (argc > 2)
     {
        if (strcmp(argv[1], "createtbl") == 0)
        {
            UtilMngCreateDbTable(&my_db,argv[2]);
        }
        else if (argc > 5 && strcmp(argv[1], "addcol") == 0)
        {
            UtilMngAddDbColumn(&my_db,argv[2],argv[3],atoi(argv[4]), atoi(argv[5]));
        }
        else if (strcmp(argv[1], "testputdata") == 0)
        {
                id = atoi(argv[2]);
                //dt[12] = 0x30+id;
                td.a += id;
                td.b += id;
                td.l += id;
                sprintf(td.name,"data%d",id);
                UtilMngPutDataToDb(&my_db, "test_table", &rcv);
        }
     }
     else
     {
        printf("Query argument is required!!\n");
     }
    return 0;
}
