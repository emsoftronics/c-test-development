#include "UtilMngDb.h"
#include <string.h>
#define DEMO_DB (UI_8 *)"demo.db"

t_util_db my_db = UM_DB_INIT;

typedef struct 
{
    int a;
    char b;
    char name[20];
    unsigned long int l;
} t_test;

t_test td = {1880,'A',"jagdish Prajapti", 7898491071};


BOOL flag = FALSE;

/**
 * @brief This is callback which will be called automatically each time for 
 * every row return by query execution.
 * @param ex_buf external buffer
 * @param argc no of colums return
 * @param argv values corresponding column
 * @param colname name of corresponding column
 *
 */

typedef struct {
    int sid;
    int cid;
    char name[32];
    int length;
    char type[15];
    void *value;
} t_my_table;

SI_32 CreateTable(t_util_db *db, UI_8 *tablename)
{
    UtilMngCreateDbTable(&my_db, tablename);    
    UtilMngAddDbColumn(&my_db, tablename, "sid",UM_DB_INTEGER, UM_DB_NOT_NULL);
    UtilMngAddDbColumn(&my_db, tablename, "cid",UM_DB_INTEGER, UM_DB_NOT_NULL);
    UtilMngAddDbColumn(&my_db, tablename, "name",UM_DB_TEXT, UM_DB_NOT_NULL);
    UtilMngAddDbColumn(&my_db, tablename, "length",UM_DB_INTEGER, UM_DB_DEFAULT_0);
    UtilMngAddDbColumn(&my_db, tablename, "type",UM_DB_TEXT, UM_DB_NOT_NULL);
    UtilMngAddDbColumn(&my_db, tablename, "value",UM_DB_BINARY, UM_DB_NULL);
}

//SI_32 UpdateTable()

static int db_callback(void * ex_buf, int argc, char **argv, char **colname)
{
    int i;
    if (flag)
    {
        printf("---------------------------------------------------------------------------------------\n");
        for(i=0; i<argc; i++){
            printf(" %12s |", colname[i]);
        }
        printf("\n---------------------------------------------------------------------------------------\n");
        flag = FALSE;
    }
    for(i=0; i<argc; i++){
        printf(" %12s |",  argv[i] ? argv[i] : "NULL");
    }
    printf("\n");
    return 0;
}

int main(int argc, char **argv )
{
    int id = 2;
    t_test tmp ={0,0,{0},0};
 //   char dt[] = "2016-09-24 00:20:55"; 
    t_Util_recrd_col_val rcv ={"id", &id, UM_DB_INTEGER, "data", &td, UM_DB_BINARY,sizeof(td)};
     if (UtilMngInitDb(&my_db, DEMO_DB, db_callback) != 0)
         printf("Database initialization failed!!\n");
     if (argc == 2)
     {
         
        flag =TRUE;
        if (UtilMngExecQuery(&my_db, argv[1], NULL) != 0)
            printf("Database query failed!!\n");
        flag =FALSE;
     }
     else if (argc > 2)
     {
        if (strcmp(argv[1], "createtbl") == 0)
        {
            UtilMngCreateDbTable(&my_db,argv[2]);
        }
        else if (argc > 5 && strcmp(argv[1], "addcol") == 0)
        {
            UtilMngAddDbColumn(&my_db,argv[2],argv[3],atoi(argv[4]), atoi(argv[5]));
        }
        else if (strcmp(argv[1], "testputdata") == 0)
        {
                id = atoi(argv[2]);
                //dt[12] = 0x30+id;
                td.a += id;
                td.b += id;
                td.l += id;
                sprintf(td.name,"data%d",id);
                UtilMngPutDataToDb(&my_db, "my_data", &rcv);
        }
        else {
            UM_DB_FOREACH_ROW(&my_db,"my_data",NULL, 1000U)
            {
                UtilMngGetDataByColName(&my_db,"data",&tmp,sizeof(tmp));
                printf(" %u.  a=%d,  b=%c,  name=\'%s\', l=%ld\n",
                (unsigned int)UM_DB_ROW_NUMBER(&my_db) ,tmp.a,tmp.b,tmp.name,tmp.l);
            }
        }
     }
     else
     {
        printf("Query argument is required!!\n");
     }
    return 0;
}
