
#ifndef __UTILMNGDB_H__
#define __UTILMNGDB_H__
#include <sqlite3.h>
#include <stdio.h>
#include <string.h>
#include "Global.h"

/**
 * UM_DB_FAILURE macro defines failure status.
 */
#define UM_DB_FAILURE           (SI_32)(-1)

/**
 * UM_DB_SUCCESS macro defines success status.
 */
#define UM_DB_SUCCESS           (SI_32)(0)

#define UM_DB_ERROR(database)  printf("%s: %s\n", __func__, sqlite3_errmsg((database)))

#define UM_DB_INIT              {{0}, NULL, NULL, NULL}


typedef int (*t_util_db_callback)(void *, int, char**, char**);

typedef struct {
    UI_8 db_filename[100];
    sqlite3 *database;
    sqlite3_stmt *sql_statement;
    t_util_db_callback callback;
} t_util_db;


